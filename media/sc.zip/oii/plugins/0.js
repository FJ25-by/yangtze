let handler = async (m, { conn, args }) => {
  let res = `./media/io.mp4`
  conn.sendFile(m.chat, res, 'yangtze.mp4', `Daftar Menu\n‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎
┏━━⊜ *_YANGTZE_* ━⊜
┃⋄ .fast-ai (Ⓛ)
┃⋄ .ai (Ⓛ)
┃⋄ .openai (Ⓛ)
┃⋄ .cekapilolhuman
┃⋄ .cekapizahwazein
┃⋄ .igstalk2 (Ⓛ)
┃⋄ .reminifree <url>
┃⋄ .m-del <url> (Ⓛ)
┃⋄ .face <url>
┃⋄ .passed <url>
┃⋄ .hitler <url> (Ⓛ)
┃⋄ .horor <text>
┃⋄ .pubg <text> (Ⓛ)
┃⋄ .triggered <url>
┃⋄ .wastedtuh <url> (Ⓛ)
┃⋄ .resize <width> <height> (reply|caption)
┃⋄ .txt <prompt>
┃⋄ .txt2 <text>  (Ⓟ)
┃⋄ .anonymous <text> (Ⓛ)
┃⋄ .aov <text> (Ⓛ) (Ⓟ)
┃⋄ .dota <text>  (Ⓟ)
┃⋄ .dragonfire <text> (Ⓛ)
┃⋄ .y-glit <text>|<text>  (Ⓟ)
┃⋄ .y-logobear <text> (Ⓛ)
┃⋄ .memo <url>
┃⋄ .onepiece <text>
┃⋄ .tweet <text>|<text>
┃⋄ .twit <text>|<text>
┃⋄ .yangtze-ai <prompt>
┃⋄ .wanted <url>
┃⋄ .ps4 <url> (Ⓛ) (Ⓟ)
┃⋄ .triggered <url>
┃⋄ .yangtzeremini <url> (Ⓛ)
┃⋄ .ytkomen <text>
┃⋄ .ytcomment <text>
┃⋄ .ytkom <text>
┃⋄ .upscale <url>
┃⋄ .upscale2 <url>
┃⋄ .upscale3 <url>
┃⋄ .YangtzeHd <url>
┗━━━━━━━━⬣

┏━━⊜ *_INFO_* ━⊜
┃⋄ .fish
┃⋄ .igowner
┃⋄ .name
┃⋄ .intro
┃⋄ .blocklist
┃⋄ .info
┃⋄ .owner
┃⋄ .donate
┃⋄ .support
┃⋄ .gcbot
┃⋄ .listprem
┃⋄ .menfess <nomor|nama pengirim|pesan>
┃⋄ .menfes <nomor|nama pengirim|pesan>
┃⋄ .help
┃⋄ .help
┃⋄ .audios
┃⋄ .ping
┃⋄ .runtime
┃⋄ .script
┃⋄ .mode
┃⋄ .os
┃⋄ .ytowner
┗━━━━━━━━⬣

┏━━⊜ *_GAME_* ━⊜
┃⋄ .asahotak
┃⋄ .casino <jumlah>
┃⋄ .iqtest
┃⋄ .tebakangka <angka>
┃⋄ .caklontong
┃⋄ .dadu
┃⋄ .delttt
┃⋄ .family100
┃⋄ .kuis
┃⋄ .lengkapikalimat
┃⋄ .math <mode>
┃⋄ .mtk <mode>
┃⋄ .siapakahaku
┃⋄ .slot <jumlah taruhan>
┃⋄ .suit
┃⋄ .susunkata
┃⋄ .tebaktebakan
┃⋄ .tebakbendera
┃⋄ .tebakgame
┃⋄ .tebakkabupaten
┃⋄ .tebakkata
┃⋄ .tebaklirik
┃⋄ .tebaklogo
┃⋄ .tebaksiapa
┃⋄ .tebaksurah
┃⋄ .tekateki
┃⋄ .tictactoe <nama room>
┃⋄ .attack
┃⋄ .atk
┃⋄ .war
┃⋄ .judilimit <jumlah>
┃⋄ .pancing <type>
┃⋄ .fightcentaur
┃⋄ .fightgriffin
┃⋄ .fightkucing
┃⋄ .fightkyubi
┃⋄ .fightnaga
┃⋄ .fightphonix
┃⋄ .hunt
┃⋄ .slot
┃⋄ .jackpot
┃⋄ .suitpvp @tag
┃⋄ .tebakanime
┃⋄ .tebakgambar
┃⋄ .ww
┃⋄ .wwjoin
┃⋄ .wwleft
┃⋄ .wwplayer
┃⋄ .wwstart
┗━━━━━━━━⬣

┏━━⊜ *_LEVEL_* ━⊜
┃⋄ .addsaldo <@user>
┃⋄ .addxp <@user>
┃⋄ .balance
┃⋄ .daily
┃⋄ .redeem harian
┃⋄ .leaderboard
┃⋄ .levelup
┃⋄ .mine
┃⋄ .maling
┃⋄ .buy
┃⋄ .buyall
┃⋄ .transfer [item] [jumlah] [@tag]
┃⋄ .work
┗━━━━━━━━⬣

┏━━⊜ *_RPG_* ━⊜
┃⋄ .reg <nama.umur>
┃⋄ .mysn
┃⋄ .unreg <Nomor Seri>
┗━━━━━━━━⬣

┏━━⊜ *_STICKER_* ━⊜
┃⋄ .stickertag (caption|reply media)
┃⋄ .sticktag <url>
┃⋄ .stickanime  (Ⓟ)
┃⋄ .animestick  (Ⓟ)
┃⋄ .attp <text>
┃⋄ .sfull
┃⋄ .stickercry
┃⋄ .emojimix <emoji+emoji> (Ⓛ)
┃⋄ .getsticker (Ⓛ)
┃⋄ .stickerhentai  (Ⓟ)
┃⋄ .stick+18  (Ⓟ)
┃⋄ .ssearch <name>  (Ⓟ)
┃⋄ .smaker (Ⓛ)
┃⋄ .smeme (teks|teks)
┃⋄ .sticker
┃⋄ .toimg <sticker>
┃⋄ .tovid
┃⋄ .ttp
┃⋄ .ttp2
┃⋄ .ttp3
┃⋄ .ttp4
┃⋄ .ttp5
┃⋄ .attp
┃⋄ .attp2
┃⋄ .attp3
┃⋄ .ttp <text>
┃⋄ .take <nama>|<autor>
┃⋄ .qc
┗━━━━━━━━⬣

┏━━⊜ *_IMAGE_* ━⊜
┃⋄ .tvid (Ⓛ) (Ⓟ)
┃⋄ .imagen (Ⓛ)
┃⋄ .girl (Ⓛ)
┃⋄ .pinterest (Ⓛ)
┃⋄ .wallpaper (Ⓛ)
┗━━━━━━━━⬣

┏━━⊜ *_AlightMotion_* ━⊜
┃⋄ .ammod
┃⋄ .p1
┃⋄ .p10
┃⋄ .p2
┃⋄ .p3
┃⋄ .p4
┃⋄ .p5
┃⋄ .p6
┃⋄ .p7
┃⋄ .p8
┃⋄ .p9
┗━━━━━━━━⬣

┏━━⊜ *_MAKER_* ━⊜
┃⋄ .logowolf <text>
┃⋄ .wolf <text>
┃⋄ .17Agustus2023 <url>
┃⋄ .3dmetal <text>
┃⋄ .3d <text>
┃⋄ .animemiku
┃⋄ .logololi <text>
┃⋄ .lolcover <text> (Ⓛ)
┃⋄ .wanteed <url>
┃⋄ .batman <text> (Ⓛ) (Ⓟ)
┃⋄ .black-pink <text>
┃⋄ .m-del <url> (Ⓛ)
┃⋄ .wallpaper-moblie
┃⋄ .water-3d
┃⋄ .water-effect
┃⋄ .water-effect2
┃⋄ .watercolor-effect
┃⋄ .wedding-silver
┃⋄ .wet-glass
┃⋄ .wings-effect
┃⋄ .women-day
┃⋄ .yasuo
┃⋄ .yellowskin-snake
┃⋄ .yena-arena-of-valor
┃⋄ .face <url>
┃⋄ .epep <text> (Coming Soon)
┃⋄ .glitch <text>  (Ⓟ)
┃⋄ .passed <url>
┃⋄ .hitler <url> (Ⓛ)
┃⋄ .horor <text>
┃⋄ .ktp <text>
┃⋄ .triggered <url>
┃⋄ .mlsertifikat <text> (Coming Soon)  (Ⓟ)
┃⋄ .pubg <text> (Ⓛ)
┃⋄ .retro <text> (Ⓛ)
┃⋄ .triggered <url>
┃⋄ .wastedtuh <url> (Ⓛ)
┃⋄ .pet <text>
┃⋄ .logololi (Ⓛ)
┃⋄ .neon (Ⓛ)
┃⋄ .devil (Ⓛ)
┃⋄ .wolf (Ⓛ)
┃⋄ .phlogo (Ⓛ)
┃⋄ .resize1 <link image>|<w>|<h> (Ⓛ)
┃⋄ .jadianime
┃⋄ .trig <url>  (Ⓟ)
┃⋄ .ywan <text>
┃⋄ .advglow <text>
┃⋄ .advancedglow <text>
┃⋄ .anonymous <text> (Ⓛ)
┃⋄ .aov <text> (Ⓛ) (Ⓟ)
┃⋄ .custom <text>|<efek>  (Ⓟ)
┃⋄ .y-ai <text>  (Ⓟ)
┃⋄ .dota <text>  (Ⓟ)
┃⋄ .dragonfire <text> (Ⓛ)
┃⋄ .fakechat <nama>|<text>|<nomor>
┃⋄ .y-glit <text>|<text>  (Ⓟ)
┃⋄ .gtt <text|text>
┃⋄ .kaneki <text>  (Ⓟ)
┃⋄ .kane <text>  (Ⓟ)
┃⋄ .y-logobear <text> (Ⓛ)
┃⋄ .futuristik <text>
┃⋄ .memo <url>
┃⋄ .mirror
┃⋄ .y-mirror
┃⋄ .ninjalogo <text|text>
┃⋄ .onepiece <text>
┃⋄ .pelet <url> (Ⓛ)
┃⋄ .rem <text>
┃⋄ .tweet <text>|<text>
┃⋄ .twit <text>|<text>
┃⋄ .y-wolf <text|text>
┃⋄ .yangtze-animeai <url>
┃⋄ .wanted <url>
┃⋄ .goldbutton <text> (Ⓛ) (Ⓟ)
┃⋄ .ps4 <url> (Ⓛ) (Ⓟ)
┃⋄ .triggered <url>
┃⋄ .phlogo <text> (Ⓛ)
┃⋄ .shadowsky <text> (Ⓛ)
┃⋄ .yangtzeremini <url> (Ⓛ)
┃⋄ .avangers <text|text>  (Ⓟ)
┃⋄ .ydevil <text>
┃⋄ .dm <text>
┃⋄ .diamond <text>
┃⋄ .hallowen <text>
┃⋄ .ilumetal <text>  (Ⓟ)
┃⋄ .ylight <text>
┃⋄ .tiger <url> (Ⓛ)
┃⋄ .ytkomen <text>
┃⋄ .ytcomment <text>
┃⋄ .ytkom <text>
┃⋄ .thunder <text>
┃⋄ .trans <text>
┃⋄ .vg <text|text>
┃⋄ .makerxn <text>
┃⋄ .marvel <text>  (Ⓟ)
┗━━━━━━━━⬣

┏━━⊜ *_PREMIUM_* ━⊜
┃⋄ .gdrive (Ⓛ) (Ⓟ)
┃⋄ .xnxx (Ⓛ) (Ⓟ)
┗━━━━━━━━⬣

┏━━⊜ *_GROUP_* ━⊜
┃⋄ .absen
┃⋄ .enable2 <option>
┃⋄ .disable2 <option>
┃⋄ .enable3 <option>
┃⋄ .disable3 <option>
┃⋄ .tagadmin
┃⋄ .add
┃⋄ .delete
┃⋄ .delwarn @user
┃⋄ .demote (@tag)
┃⋄ .infogp
┃⋄ .hidetag
┃⋄ .invite <628xxx>
┃⋄ .kick @user
┃⋄ .tailu @user
┃⋄ .link
┃⋄ .poll <hola|como|xd>
┃⋄ .perfil
┃⋄ .promote
┃⋄ .resetlink
┃⋄ .revoke
┃⋄ .setbye <text>
┃⋄ .group *open/close*
┃⋄ .setwelcome <text>
┃⋄ .simulate <event> @user
┃⋄ .staff
┃⋄ .tagall
┃⋄ .totag
┃⋄ .warn @user
┃⋄ .warns
┃⋄ .gcsider
┃⋄ .setppgc
┃⋄ .setppgcpanjang
┃⋄ .tagall (Ⓛ)
┃⋄ .tagme
┃⋄ .checkexpired
┃⋄ .promote @user
┗━━━━━━━━⬣

┏━━⊜ *_EN/DS FITUR_* ━⊜
┃⋄ .enable <option>
┃⋄ .disable <option>
┗━━━━━━━━⬣

┏━━⊜ *_ANIME_* ━⊜
┃⋄ .waifu (Ⓛ)
┃⋄ .neko (Ⓛ)
┃⋄ .megumin (Ⓛ)
┃⋄ .loli (Ⓛ)
┗━━━━━━━━⬣

┏━━⊜ *_ANIME REACCION_* ━⊜
┃⋄ .kill @tag (Ⓛ)
┃⋄ .kiss @tag (Ⓛ)
┃⋄ .pat @tag (Ⓛ)
┃⋄ .slap @tag (Ⓛ)
┗━━━━━━━━⬣

┏━━⊜ *_DOWNLOADER_* ━⊜
┃⋄ .asupan  (Ⓟ)
┃⋄ .douyinslide
┃⋄ .facebook <url> (Ⓛ)
┃⋄ .gdrive (Ⓛ) (Ⓟ)
┃⋄ .gitclone <url> (Ⓛ)
┃⋄ .igstalk
┃⋄ .igstalk2 (Ⓛ)
┃⋄ .dlpinterest <link>
┃⋄ .play
┃⋄ .tiktok (Ⓛ)
┃⋄ .tiktokslide
┃⋄ .ttslide
┃⋄ .slide
┃⋄ .twitter
┃⋄ .twitdl
┃⋄ .twitterdl
┃⋄ .ytmp3 <url> (Ⓛ)
┃⋄ .ytsearch
┃⋄ .ytmp4 <link yt> (Ⓛ)
┗━━━━━━━━⬣

┏━━⊜ *_TOOLS_* ━⊜
┃⋄ .anonfiles <media> <nama file>
┃⋄ .apk <query>
┃⋄ .langganan
┃⋄ .encrypt *<texto>*
┃⋄ .ofuscar *<texto>*
┃⋄ .infogempa
┃⋄ .gempa
┃⋄ .allprofile [@user]
┃⋄ .dashboard
┃⋄ .kenon  (Ⓟ)
┃⋄ .roboguru <query>
┃⋄ .akungratis
┃⋄ .freeaccount
┃⋄ .blur <reply media>
┃⋄ .get
┃⋄ .jadwaltv
┃⋄ .jarak <dari|ke>
┃⋄ .modapk
┃⋄ .paragraph (Ⓛ)
┃⋄ .topdf
┃⋄ .pesankosong
┃⋄ .spam <teks>
┃⋄ .qr <teks>
┃⋄ .qrcode <teks>
┃⋄ .react <emoji>
┃⋄ .repeat <teks>
┃⋄ .repeat2 <teks>  (Ⓟ)
┃⋄ .length <amount>
┃⋄ .resize1 <link image>|<w>|<h> (Ⓛ)
┃⋄ .shorturl2 (Ⓛ)
┃⋄ .shorturl3
┃⋄ .spamwa <number>|<mesage>|<no of messages>
┃⋄ .toaksara <teks>
┃⋄ .ceknomor
┃⋄ .truecaller
┃⋄ .readqr <link> (Ⓛ)
┃⋄ .waktu <daerah>
┃⋄ .zodiac *2004 12 21*
┃⋄ .zoom <pass>
┃⋄ .artikata
┃⋄ .artimimpi
┃⋄ .artinama
┃⋄ .cal <ecuacion>
┃⋄ .cekresolution *<foto>*
┃⋄ .cekreso *<foto>*
┃⋄ .deenc <text>
┃⋄ .deencrypt <text>
┃⋄ .enc <text>
┃⋄ .encrypt <text>
┃⋄ .fakedoc <docname> --size(ukuranfakefile) <type>
┃⋄ .--apk
┃⋄ .--apks
┃⋄ .--png
┃⋄ .--jpg
┃⋄ .--mp4
┃⋄ .--mp3
┃⋄ .--bin
┃⋄ .--doc
┃⋄ .--pdf
┃⋄ .--zip
┃⋄ .fake <text> @user <text2>
┃⋄ .getcaption
┃⋄ .getprofile *<@tag>*
┃⋄ .google (Ⓛ)
┃⋄ .jadwalsholat
┃⋄ .apk <kota>
┃⋄ .lyrics
┃⋄ .removebg (Ⓛ)
┃⋄ .totexto *<imagen>*
┃⋄ .readmore <text1>|<text2>
┃⋄ .readvo
┃⋄ .remini  (Ⓟ)
┃⋄ .rmbg <url> (Ⓛ)
┃⋄ .resize <width> <height> (reply|caption)
┃⋄ .readviewonce
┃⋄ .savecontact *@tag*
┃⋄ .ssweb <url>
┃⋄ .sspc <url>
┃⋄ .sshp <url>
┃⋄ .sstablet <url>
┃⋄ .tomorse
┃⋄ .totextmorse
┃⋄ .tourl
┃⋄ .translate <bahasa> <text>
┃⋄ .tts <lang> <teks>
┃⋄ .totextmorse
┃⋄ .wait <caption|reply>
┃⋄ .wastalk
┃⋄ .wikipedia <text>
┃⋄ .apa <pencarian>
┃⋄ .yangtzesearch <pencarian>
┃⋄ .ytstalk <query>
┃⋄ .subscribe
┃⋄ .upscale <url>
┃⋄ .upscale2 <url>
┃⋄ .upscale3 <url>
┃⋄ .YangtzeHd <url>
┗━━━━━━━━⬣

┏━━⊜ *_FUN_* ━⊜
┃⋄ .afk <alasan>
┃⋄ .imageai
┃⋄ .ceritahoror
┃⋄ .cerpen
┃⋄ .ruangguru
┃⋄ .cpasangan
┃⋄ .alay
┃⋄ .apakah <teks>?
┃⋄ .artinama [name]
┃⋄ .cantikcek
┃⋄ .alay
┃⋄ .ceksifat <nama>
┃⋄ .masadepannya <nama>
┃⋄ .darkjokes
┃⋄ .fitnah <teks> @user <teks>
┃⋄ .memek
┃⋄ .bego
┃⋄ .goblok
┃⋄ .janda
┃⋄ .perawan
┃⋄ .babi
┃⋄ .tolol
┃⋄ .pinter
┃⋄ .pintar
┃⋄ .asu
┃⋄ .bodoh
┃⋄ .gay
┃⋄ .lesby
┃⋄ .bajingan
┃⋄ .jancok
┃⋄ .tukangngewe
┃⋄ .anjing
┃⋄ .ngentod
┃⋄ .ngentot
┃⋄ .monyet
┃⋄ .pencoli
┃⋄ .mastah
┃⋄ .newbie
┃⋄ .bangsat
┃⋄ .bangke
┃⋄ .sange
┃⋄ .sangean
┃⋄ .dakjal
┃⋄ .horny
┃⋄ .wibu
┃⋄ .puki
┃⋄ .peak
┃⋄ .pantex
┃⋄ .pantek
┃⋄ .setan
┃⋄ .iblis
┃⋄ .cacat
┃⋄ .yatim
┃⋄ .piatu
┃⋄ .gantengcek
┃⋄ .gay @user
┃⋄ .gaycek
┃⋄ .howgay siapa?
┃⋄ .howpintar siapa?
┃⋄ .howcantik siapa?
┃⋄ .howganteng siapa?
┃⋄ .howgabut siapa?
┃⋄ .howgila siapa?
┃⋄ .howlesbi siapa?
┃⋄ .howstress siapa?
┃⋄ .howbucin siapa?
┃⋄ .howjones siapa?
┃⋄ .howsadboy siapa?
┃⋄ .stupid
┃⋄ .foolish
┃⋄ .smart
┃⋄ .idiot
┃⋄ .gay
┃⋄ .lesbi
┃⋄ .bastard
┃⋄ .stubble
┃⋄ .dog
┃⋄ .fuck
┃⋄ .ape
┃⋄ .noob
┃⋄ .great
┃⋄ .horny
┃⋄ .wibu
┃⋄ .asshole
┃⋄ .handsome
┃⋄ .beautiful
┃⋄ .cute
┃⋄ .kind
┃⋄ .ugly
┃⋄ .pretty
┃⋄ .lesbian
┃⋄ .randi
┃⋄ .gandu
┃⋄ .madarchod
┃⋄ .kala
┃⋄ .gora
┃⋄ .chutiya
┃⋄ .nibba
┃⋄ .nibbi
┃⋄ .bhosdiwala
┃⋄ .chutmarika
┃⋄ .bokachoda
┃⋄ .suarerbaccha
┃⋄ .bolochoda
┃⋄ .muthal
┃⋄ .muthbaaz
┃⋄ .randibaaz
┃⋄ .topibaaz
┃⋄ .cunt
┃⋄ .nerd
┃⋄ .behenchod
┃⋄ .behnchoda
┃⋄ .bhosdika
┃⋄ .nerd
┃⋄ .mc
┃⋄ .bsdk
┃⋄ .bhosdk
┃⋄ .nigger
┃⋄ .loda
┃⋄ .laund
┃⋄ .nigga
┃⋄ .noobra
┃⋄ .tharki
┃⋄ .nibba
┃⋄ .nibbi
┃⋄ .mumu
┃⋄ .rascal
┃⋄ .scumbag
┃⋄ .nuts
┃⋄ .comrade
┃⋄ .fagot
┃⋄ .scoundrel
┃⋄ .ditch
┃⋄ .dope
┃⋄ .gucci
┃⋄ .lit
┃⋄ .dumbass
┃⋄ .sexy
┃⋄ .crackhead
┃⋄ .mf
┃⋄ .motherfucker
┃⋄ .dogla
┃⋄ .bewda
┃⋄ .boka
┃⋄ .khanki
┃⋄ .bal
┃⋄ .sucker
┃⋄ .fuckboy
┃⋄ .playboy
┃⋄ .fuckgirl
┃⋄ .playgirl
┃⋄ .hot
┃⋄ .kerang <teks>
┃⋄ .kerangajaib <teks>
┃⋄ .cekkontol <nama>
┃⋄ .cekmemek <nama>
┃⋄ .namaninja *<text>*
┃⋄ .pernikahan <tgl>|<bln>|<tahun>
┃⋄ .cekrating
┃⋄ .rate
┃⋄ .rating
┃⋄ .taugasih
┃⋄ .tomp3
┃⋄ .top
┃⋄ .toav
┃⋄ .wibucek
┃⋄ .wr (Ⓛ)
┃⋄ .wrhero (Ⓛ)
┃⋄ .meme
┃⋄ .jadizombie
┃⋄ .reaction <reply>
┃⋄ .mengaji
┃⋄ .ngaji
┃⋄ .checktoxic <kata>
┗━━━━━━━━⬣

┏━━⊜ *_DATABASE_* ━⊜
┃⋄ .delcmd <text>
┃⋄ .listcmd
┃⋄ .setcmd <txt>
┗━━━━━━━━⬣

┏━━⊜ *_NSFW +18_* ━⊜
┃⋄ .hijaber
┃⋄ .masturbation  (Ⓟ)
┃⋄ .nekopoi  (Ⓟ)
┃⋄ .ahegao  (Ⓟ)
┃⋄ .ass (Ⓛ)
┃⋄ .animebdsm  (Ⓟ)
┃⋄ .blowjob (Ⓛ)
┃⋄ .boobs (Ⓛ)
┃⋄ .cuckold  (Ⓟ)
┃⋄ .ero  (Ⓟ)
┃⋄ .femdom  (Ⓟ)
┃⋄ .foot  (Ⓟ)
┃⋄ .gangbang  (Ⓟ)
┃⋄ .hentai
┃⋄ .vidhentai  (Ⓟ)
┃⋄ .hinata  (Ⓟ)
┃⋄ .hnt_gifs  (Ⓟ)
┃⋄ .husbu
┃⋄ .kodenuklir
┃⋄ .manga  (Ⓟ)
┃⋄ .xneko (Ⓛ)
┃⋄ .ass (Ⓛ)
┃⋄ .boobs (Ⓛ)
┃⋄ .lesbian (Ⓛ)
┃⋄ .pussy (Ⓛ)
┃⋄ .pack (Ⓛ)
┃⋄ .ometv
┃⋄ .paptt  (Ⓟ)
┃⋄ .pussy  (Ⓟ)
┃⋄ .xnxx (Ⓛ) (Ⓟ)
┃⋄ .xwaifu
┃⋄ .pussy (Ⓛ)
┃⋄ .stickerhentai  (Ⓟ)
┃⋄ .stick+18  (Ⓟ)
┃⋄ .viral
┃⋄ .yuri (Ⓛ)
┗━━━━━━━━⬣

┏━━⊜ *_NSFW ANIME_* ━⊜
┃⋄ .xwaifu (Ⓛ)
┃⋄ .xneko (Ⓛ)
┃⋄ .blowjob (Ⓛ)
┃⋄ .trap (Ⓛ)
┃⋄ .yuri (Ⓛ)
┃⋄ .cum (Ⓛ)
┃⋄ .hentai (Ⓛ)
┗━━━━━━━━⬣

┏━━⊜ *_OWNER_* ━⊜
┃⋄ .block
┃⋄ .unblock
┃⋄ .pushkontak
┃⋄ .men
┃⋄ .add/tambahmods <@user>
┃⋄ .prem *@tag|days*
┃⋄ .bugmenu
┃⋄ .deleteuser
┃⋄ .enable2 <option>
┃⋄ .disable2 <option>
┃⋄ .enable3 <option>
┃⋄ .disable3 <option>
┃⋄ .addprem [@user] <hari>
┃⋄ .nomerlink <nomer>
┃⋄ .nrl <nomer>
┃⋄ .cheatlimit
┃⋄ .delowner [@user]
┃⋄ .setppbotfull
┃⋄ .expired <days>
┃⋄ .addowner [@user]
┃⋄ .addprem <@tag>
┃⋄ .banchat
┃⋄ .listban
┃⋄ .ban @user
┃⋄ .broadcast
┃⋄ .cariteman
┃⋄ .caridoi
┃⋄ .cleartmp
┃⋄ .delexpired
┃⋄ .delprem @user
┃⋄ .email
┃⋄ .getplugin
┃⋄ .join <chat.whatsapp.com> <days>
┃⋄ .reset <62xxx>
┃⋄ .restart
┃⋄ .setbotbio <teks>
┃⋄ .sfp <teks>
┃⋄ .unbanchat
┃⋄ .unban @user
┃⋄ .update
┃⋄ .promote @user
┃⋄ .saveplugin <name file>
┃⋄ .savefile <name file>
┃⋄ .titlein <nama>
┃⋄ .upsw <text|reply>
┃⋄ .upsw <text>
┗━━━━━━━━⬣

┏━━⊜ *_ADVANCE_* ━⊜
┃⋄ >
┃⋄ =>
┃⋄ $
┗━━━━━━━━⬣

┏━━⊜ *_internet_* ━⊜
┃⋄ .fast-ai (Ⓛ)
┃⋄ .ppcouple
┃⋄ .ppcp
┃⋄ .ppcouple2
┃⋄ .ppcp2
┃⋄ .ppcouplev2
┃⋄ .ppcpv2
┃⋄ .apk <query>
┃⋄ .bkpindo <query>  (Ⓟ)
┃⋄ .bkpsearch <query>  (Ⓟ)
┃⋄ .brainly <soal>
┃⋄ .cecan
┃⋄ .cekapi-botcahx.live
┃⋄ .cekapilolhuman
┃⋄ .cekapizahwazein
┃⋄ .darkjokes
┃⋄ .infogempa
┃⋄ .gempa
┃⋄ .googleket <search>
┃⋄ .happymod <query>
┃⋄ .mod <query>
┃⋄ .heroml <nama hero>
┃⋄ .gunung
┃⋄ .wptechnogy
┃⋄ .animal <hewan>
┃⋄ .bts
┃⋄ .cecanrandom
┃⋄ .cecanukhty
┃⋄ .cuaca
┃⋄ .jadwalbola
┃⋄ .katanime
┃⋄ .kbbi <teks>
┃⋄ .kodebahasa
┃⋄ .coffee
┃⋄ .kopi
┃⋄ .server <type> <ip> <port>
┃⋄ .spek
┃⋄ .device
┃⋄ .spesifikasi
┃⋄ .jadizombie
┃⋄ .jadwalbola2
┃⋄ .ytcomment
┃⋄ .ytkomen
┃⋄ .musik
┃⋄ .nekoo (Ⓛ)
┃⋄ .nomorhoki <nomor>
┃⋄ .ppkopel
┃⋄ .renungan
┃⋄ .roboguru <query>
┃⋄ .jarak <dari|ke>
┃⋄ .short <link>
┃⋄ .readqr <link> (Ⓛ)
┃⋄ .apk <kota>
┃⋄ .imdb
┃⋄ .movie
┃⋄ .wikipedia <text>
┃⋄ .apa <pencarian>
┃⋄ .yangtzesearch <pencarian>
┃⋄ .yangtze-ai <prompt>
┃⋄ .yaimg <dicari>
┃⋄ .yangtzeimage <dicari>
┃⋄ .yimg <dicari>
┃⋄ .ytstalk <query>
┗━━━━━━━━⬣

┏━━⊜ *_logo_* ━⊜
┃⋄ .logowolf <text>
┃⋄ .wolf <text>
┃⋄ .17Agustus2023 <url>
┃⋄ .3dmetal <text>
┃⋄ .3d <text>
┃⋄ .logololi <text>
┃⋄ .lolcover <text> (Ⓛ)
┃⋄ .wanteed <url>
┃⋄ .batman <text> (Ⓛ) (Ⓟ)
┃⋄ .black-pink <text>
┃⋄ .m-del <url> (Ⓛ)
┃⋄ .face <url>
┃⋄ .epep <text> (Coming Soon)
┃⋄ .gameover <text>
┃⋄ .glitch <text>  (Ⓟ)
┃⋄ .logo-harrypotter <text>
┃⋄ .hitler <url> (Ⓛ)
┃⋄ .horor <text>
┃⋄ .ktp <text>
┃⋄ .triggered <url>
┃⋄ .logo-pubg <text>
┃⋄ .mlsertifikat <text> (Coming Soon)  (Ⓟ)
┃⋄ .logo-naruto <text>
┃⋄ .pubg <text> (Ⓛ)
┃⋄ .retro <text> (Ⓛ)
┃⋄ .triggered <url>
┃⋄ .wastedtuh <url> (Ⓛ)
┃⋄ .pet <text>
┃⋄ .ywan <text>
┃⋄ .advglow <text>
┃⋄ .advancedglow <text>
┃⋄ .anonymous <text> (Ⓛ)
┃⋄ .aov <text> (Ⓛ) (Ⓟ)
┃⋄ .custom <text>|<efek>  (Ⓟ)
┃⋄ .dota <text>  (Ⓟ)
┃⋄ .dragonfire <text> (Ⓛ)
┃⋄ .fakechat <nama>|<text>|<nomor>
┃⋄ .y-glit <text>|<text>  (Ⓟ)
┃⋄ .gtt <text|text>
┃⋄ .kaneki <text>  (Ⓟ)
┃⋄ .kane <text>  (Ⓟ)
┃⋄ .y-logobear <text> (Ⓛ)
┃⋄ .futuristik <text>
┃⋄ .memo <url>
┃⋄ .ninjalogo <text|text>
┃⋄ .onepiece <text>
┃⋄ .pelet <url> (Ⓛ)
┃⋄ .rem <text>
┃⋄ .y-wolf <text|text>
┃⋄ .yangtze-animeai <url>
┃⋄ .wanted <url>
┃⋄ .goldbutton <text> (Ⓛ) (Ⓟ)
┃⋄ .ps4 <url> (Ⓛ) (Ⓟ)
┃⋄ .triggered <url>
┃⋄ .phlogo <text> (Ⓛ)
┃⋄ .yangtzeremini <url> (Ⓛ)
┃⋄ .avangers <text|text>  (Ⓟ)
┃⋄ .ydevil <text>
┃⋄ .dm <text>
┃⋄ .diamond <text>
┃⋄ .hallowen <text>
┃⋄ .ilumetal <text>  (Ⓟ)
┃⋄ .ylight <text>
┃⋄ .tiger <url> (Ⓛ)
┃⋄ .ytkomen <text>
┃⋄ .ytcomment <text>
┃⋄ .ytkom <text>
┃⋄ .thunder <text>
┃⋄ .trans <text>
┃⋄ .vg <text|text>
┃⋄ .makerxn <text>
┃⋄ .marvel <text>  (Ⓟ)
┗━━━━━━━━⬣

┏━━⊜ *_info_* ━⊜
┃⋄ .version
┃⋄ .verbot
┃⋄ .ver
┃⋄ .statusbot
┃⋄ .user
┃⋄ .allprofile [@user]
┃⋄ .boost
┃⋄ .refresh
┃⋄ .owner
┃⋄ .creator
┃⋄ .jaringan
┃⋄ .infopremium
┃⋄ .report <teks>
┃⋄ .totalfitur
┃⋄ .listpremium2
┃⋄ .request <teks>
┃⋄ .role
┃⋄ .rules
┃⋄ .statserver
┃⋄ .ai  (Ⓟ)
┃⋄ .openai  (Ⓟ)
┃⋄ .chatgpt  (Ⓟ)
┗━━━━━━━━⬣

┏━━⊜ *_absen_* ━⊜
┃⋄ .absen
┃⋄ .cekabsen
┃⋄ .hapusabsen
┃⋄ .mulaiabsen [teks]
┗━━━━━━━━⬣

┏━━⊜ *_xp_* ━⊜
┃⋄ .addenergi <@user> <amount>
┃⋄ .ceksn
┃⋄ .daftar <nama>.<umur>
┃⋄ .register <nama>.<umur>
┃⋄ .ceklimit <@user>
┃⋄ .limit <@user>
┃⋄ .my
┃⋄ .tomoney <jumlah>
┃⋄ .buylimit
┃⋄ .buyall
┃⋄ .rpgdaily
┃⋄ .rpgclaim
┃⋄ .leaderboard [jumlah user]
┃⋄ .lb [jumlah user]
┗━━━━━━━━⬣

┏━━⊜ *_ai_* ━⊜
┃⋄ .arcane  (Ⓟ)
┃⋄ .art  (Ⓟ)
┃⋄ .comics  (Ⓟ)
┃⋄ .disney  (Ⓟ)
┃⋄ .jojo  (Ⓟ)
┃⋄ .renaissance  (Ⓟ)
┃⋄ .yasuo  (Ⓟ)
┃⋄ .ai (Ⓛ)
┃⋄ .openai (Ⓛ)
┃⋄ .aremini  (Ⓟ)
┃⋄ .enhancer  (Ⓟ)
┃⋄ .hdr  (Ⓟ)
┃⋄ .colorize  (Ⓟ)
┃⋄ .txt <prompt>
┃⋄ .txt2 <text>  (Ⓟ)
┃⋄ .y-ai <text>  (Ⓟ)
┗━━━━━━━━⬣

┏━━⊜ *_anime_* ━⊜
┃⋄ .animeloli
┃⋄ .animeinfo <anime>
┃⋄ .animelink
┃⋄ .otakudesu <Apa>
┃⋄ .simpown
┃⋄ .animesearch (Ⓛ)
┃⋄ .search (Ⓛ)
┃⋄ .dlanime
┃⋄ .komikusearch
┃⋄ .konachan  (Ⓟ)
┃⋄ .akira (Ⓛ)
┃⋄ .akiyama (Ⓛ)
┃⋄ .anna (Ⓛ)
┃⋄ .asuna (Ⓛ)
┃⋄ .ayuzawa (Ⓛ)
┃⋄ .boruto (Ⓛ)
┃⋄ .chiho (Ⓛ)
┃⋄ .chitoge (Ⓛ)
┃⋄ .deidara (Ⓛ)
┃⋄ .erza (Ⓛ)
┃⋄ .elaina (Ⓛ)
┃⋄ .eba (Ⓛ)
┃⋄ .emilia (Ⓛ)
┃⋄ .hestia (Ⓛ)
┃⋄ .hinata (Ⓛ)
┃⋄ .inori (Ⓛ)
┃⋄ .isuzu (Ⓛ)
┃⋄ .itachi (Ⓛ)
┃⋄ .itori (Ⓛ)
┃⋄ .kaga (Ⓛ)
┃⋄ .kagura (Ⓛ)
┃⋄ .kaori (Ⓛ)
┃⋄ .keneki (Ⓛ)
┃⋄ .kotori (Ⓛ)
┃⋄ .kurumi (Ⓛ)
┃⋄ .madara (Ⓛ)
┃⋄ .mikasa (Ⓛ)
┃⋄ .miku (Ⓛ)
┃⋄ .minato (Ⓛ)
┃⋄ .naruto (Ⓛ)
┃⋄ .nezuko (Ⓛ)
┃⋄ .sagiri (Ⓛ)
┃⋄ .sasuke (Ⓛ)
┃⋄ .sakura (Ⓛ)
┃⋄ .cosplay (Ⓛ)
┗━━━━━━━━⬣

┏━━⊜ *_quotes|anime_* ━⊜
┃⋄ .kataanimesad
┗━━━━━━━━⬣

┏━━⊜ *_anonymous_* ━⊜
┃⋄ .start
┃⋄ .leave
┃⋄ .next
┗━━━━━━━━⬣

┏━━⊜ *_asupan_* ━⊜
┃⋄ .asupandouyin  (Ⓟ)
┃⋄ .euni (Ⓛ)
┃⋄ .kayes (Ⓛ)
┃⋄ .lokal (Ⓛ)
┃⋄ .china
┃⋄ .indonesia
┃⋄ .japan
┃⋄ .korea
┃⋄ .malaysia
┃⋄ .thailand
┃⋄ .vietnam
┃⋄ .natajadeh
┃⋄ .notnot (Ⓛ)
┃⋄ .girl (Ⓛ)
┃⋄ .cwe (Ⓛ)
┗━━━━━━━━⬣

┏━━⊜ *_premium_* ━⊜
┃⋄ .asupanloli  (Ⓟ)
┃⋄ .filebokep  (Ⓟ)
┃⋄ .black-pink <text>
┃⋄ .indohot  (Ⓟ)
┃⋄ .terorbug <nomer>  (Ⓟ)
┃⋄ .creategroup
┃⋄ .stickanime  (Ⓟ)
┃⋄ .animestick  (Ⓟ)
┃⋄ .stickhoppai  (Ⓟ)
┃⋄ .hoppai  (Ⓟ)
┃⋄ .ssearch <name>  (Ⓟ)
┗━━━━━━━━⬣

┏━━⊜ *_audioanime_* ━⊜
┃⋄ .ahh
┃⋄ .ara
┃⋄ .ganbare
┃⋄ .konichiwa
┃⋄ .nani
┃⋄ .rikka
┃⋄ .ultra
┃⋄ .voice
┃⋄ .voice1
┃⋄ .voice2
┃⋄ .voice3
┃⋄ .voice4
┃⋄ .voice5
┃⋄ .voice6
┃⋄ .voice7
┃⋄ .voice8
┃⋄ .voice9
┃⋄ .voice10
┃⋄ .voice11
┃⋄ .voice12
┃⋄ .voice13
┃⋄ .voice14
┃⋄ .voice15
┃⋄ .voice16
┃⋄ .voice17
┃⋄ .voice18
┃⋄ .voice19
┃⋄ .voice20
┃⋄ .voice21
┃⋄ .voice22
┃⋄ .voice23
┃⋄ .voice24
┃⋄ .voice25
┃⋄ .voice26
┃⋄ .voice27
┃⋄ .voice28
┃⋄ .voice29
┃⋄ .voice30
┃⋄ .voice31
┃⋄ .voice32
┃⋄ .voice33
┃⋄ .voice34
┃⋄ .voice35
┃⋄ .voice36
┃⋄ .voice37
┃⋄ .voice38
┃⋄ .voice39
┃⋄ .voice40
┃⋄ .voice41
┃⋄ .voice42
┃⋄ .voice43
┃⋄ .voice44
┃⋄ .voice45
┃⋄ .voice46
┃⋄ .voice47
┃⋄ .voice48
┃⋄ .voice49
┃⋄ .voice50
┃⋄ .voice51
┃⋄ .voice52
┃⋄ .voice53
┃⋄ .voice54
┃⋄ .voice55
┃⋄ .voice56
┃⋄ .voice57
┃⋄ .voice58
┃⋄ .voice59
┃⋄ .voice60
┃⋄ .voice61
┃⋄ .voice62
┃⋄ .voice63
┃⋄ .voice64
┃⋄ .voice65
┃⋄ .voice66
┃⋄ .voice67
┃⋄ .voice68
┃⋄ .voice69
┃⋄ .voice70
┃⋄ .voice71
┃⋄ .voice72
┃⋄ .voice73
┃⋄ .voice74
┃⋄ .voice75
┃⋄ .voice76
┃⋄ .voice77
┃⋄ .voice78
┃⋄ .voice79
┃⋄ .voice80
┃⋄ .voice81
┃⋄ .voice82
┃⋄ .voice83
┃⋄ .voice84
┃⋄ .voice85
┃⋄ .voice86
┃⋄ .voice87
┃⋄ .voice88
┃⋄ .voice89
┃⋄ .voice90
┃⋄ .voice91
┃⋄ .voice92
┃⋄ .voice93
┃⋄ .voice94
┃⋄ .voice95
┃⋄ .voice96
┃⋄ .voice97
┃⋄ .yemete
┃⋄ .yuno
┗━━━━━━━━⬣

┏━━⊜ *_audio_* ━⊜
┃⋄ .cut <text>
┃⋄ .bass [vn]
┃⋄ .blown [vn]
┃⋄ .deep [vn]
┃⋄ .earrape [vn]
┃⋄ .fast [vn]
┃⋄ .fat [vn]
┃⋄ .nightcore [vn]
┃⋄ .reverse [vn]
┃⋄ .robot [vn]
┃⋄ .slow [vn]
┃⋄ .smooth [vn]
┃⋄ .tupai [vn]
┃⋄ .musik
┗━━━━━━━━⬣

┏━━⊜ *_rpg_* ━⊜
┃⋄ .bank
┃⋄ .nabung <jumlah>
┃⋄ .tarik <jumlah>
┃⋄ .berkebon
┃⋄ .cekmoney
┃⋄ .duar <@tag>
┃⋄ .kandang
┃⋄ .open <crate>
┃⋄ .gacha <crate>
┃⋄ .adventure
┃⋄ .petualang
┃⋄ .berpetualang
┃⋄ .mulung
┃⋄ .pull
┃⋄ .pullall
┃⋄ .atm
┃⋄ .atmall
┃⋄ .bansos
┃⋄ .berburu
┃⋄ .berdagang @[tag]
┃⋄ .judi [jumlah]
┃⋄ .bonus
┃⋄ .hadiah
┃⋄ .bunuh  (Ⓟ)
┃⋄ .rpgcollect
┃⋄ .cd
┃⋄ .cooldown
┃⋄ .craft
┃⋄ .dompet
┃⋄ .limit
┃⋄ .eat
┃⋄ .makan
┃⋄ .feed [pet type]
┃⋄ .fighting
┃⋄ .gaji
┃⋄ .gajian
┃⋄ .heal
┃⋄ .inventory
┃⋄ .inv
┃⋄ .Karung
┃⋄ .kerja
┃⋄ .work
┃⋄ .kotakikan
┃⋄ .kolam
┃⋄ .kolamikan
┃⋄ .malingrpg
┃⋄ .mengaji
┃⋄ .ngaji
┃⋄ .mentransfer <Args>
┃⋄ .merampok *@tag*
┃⋄ .mining
┃⋄ .monthly
┃⋄ .nambang
┃⋄ .nebang
┃⋄ .ngewe  (Ⓟ)
┃⋄ .ngocok
┃⋄ .nguli
┃⋄ .ojek
┃⋄ .petshop
┃⋄ .cat
┃⋄ .dog
┃⋄ .fox
┃⋄ .horse
┃⋄ .feed
┃⋄ .petfood
┃⋄ .polisi
┃⋄ .premgift <kode>  (Ⓟ)
┃⋄ .profile <url>
┃⋄ .ramuan [pet type]
┃⋄ .redeem
┃⋄ .repair
┃⋄ .rob
┃⋄ .roket
┃⋄ .selectskill
┃⋄ .pilihskill
┃⋄ .shop <sell|buy> <args>
┃⋄ .selectskill <type>
┃⋄ .slot
┃⋄ .jackpot
┃⋄ .weekly
┗━━━━━━━━⬣

┏━━⊜ *_downloader_* ━⊜
┃⋄ .bkptw  (Ⓟ)
┃⋄ .bkptwt  (Ⓟ)
┃⋄ .douyin
┃⋄ .googledrive
┃⋄ .gd
┃⋄ .gdrv
┃⋄ .mediafire <url>
┃⋄ .ttmp3
┃⋄ .asupantiktok <username>
┃⋄ .capcut <url>
┃⋄ .capcutwm <url>
┃⋄ .facebookaudio
┃⋄ .gdrive
┃⋄ .tiktokfoto <username>
┃⋄ .pptiktok <username>
┃⋄ .sfile
┃⋄ .dls <link>
┃⋄ .dlsoundcloud <link>
┃⋄ .soundcloud <link>
┃⋄ .tiktok2 <url>
┃⋄ .tt2 <url>
┃⋄ .ytshorts
┃⋄ .youtubeshorts
┃⋄ .shorts
┃⋄ .short
┃⋄ .happymod <query>
┃⋄ .mod <query>
┃⋄ .ig
┃⋄ .snackvideo <url>
┃⋄ .spotify
┃⋄ .stalktiktok2 <username>
┃⋄ .dttnowm <link>
┃⋄ .dtt <link>
┃⋄ .twitter <url>
┗━━━━━━━━⬣

┏━━⊜ *_Yangtze_* ━⊜
┃⋄ .langganan
┃⋄ .sumbang
┃⋄ .nowa
┃⋄ .squad
┃⋄ .blur <reply media>
┃⋄ .jarak <dari|ke>
┃⋄ .apa <pencarian>
┃⋄ .yangtzesearch <pencarian>
┃⋄ .y-ai <text>  (Ⓟ)
┃⋄ .yaimg <dicari>
┃⋄ .yangtzeimage <dicari>
┃⋄ .yimg <dicari>
┗━━━━━━━━⬣

┏━━⊜ *_catatan_* ━⊜
┃⋄ .buatcatatan <title|isi>
┃⋄ .hapuscatatan title
┃⋄ .lihatcatatan <title>
┗━━━━━━━━⬣

┏━━⊜ *_quotes_* ━⊜
┃⋄ .cerpen2
┃⋄ .q-bucin
┃⋄ .dare
┃⋄ .fakta
┃⋄ .galau
┃⋄ .gombal
┃⋄ .hacker
┃⋄ .islam
┃⋄ .jawa
┃⋄ .katabijak
┃⋄ .motivasi
┃⋄ .ngawur
┃⋄ .pantun
┃⋄ .senja
┃⋄ .sindiran
┃⋄ .truth
┃⋄ .vidiogalau
┃⋄ .quotes
┗━━━━━━━━⬣

┏━━⊜ *_berita_* ━⊜
┃⋄ .cnnnews
┃⋄ .tribunnews
┗━━━━━━━━⬣

┏━━⊜ *_stalker_* ━⊜
┃⋄ .tiktokstalk (Ⓛ)
┃⋄ .aovstalk (Ⓛ)
┃⋄ .stalkaov (Ⓛ)
┃⋄ .stalknik
┃⋄ .nik
┃⋄ .githubstalk <username>
┃⋄ .igstalk3 <username>
┃⋄ .mlstalk <id>
┃⋄ .stalkff <id>
┗━━━━━━━━⬣

┏━━⊜ *_18+_* ━⊜
┃⋄ .dood
┗━━━━━━━━⬣

┏━━⊜ *_kerang_* ━⊜
┃⋄ .apakah <teks>?
┃⋄ .bisakah <pertanyaan>
┃⋄ .ceksifat <nama>
┃⋄ .masadepannya <nama>
┃⋄ .howgay siapa?
┃⋄ .howpintar siapa?
┃⋄ .howcantik siapa?
┃⋄ .howganteng siapa?
┃⋄ .howgabut siapa?
┃⋄ .howgila siapa?
┃⋄ .howlesbi siapa?
┃⋄ .howstress siapa?
┃⋄ .howbucin siapa?
┃⋄ .howjones siapa?
┃⋄ .howsadboy siapa?
┃⋄ .kerang <teks>
┃⋄ .kerangajaib <teks>
┗━━━━━━━━⬣

┏━━⊜ *_dewasa_* ━⊜
┃⋄ .filebokep  (Ⓟ)
┗━━━━━━━━⬣

┏━━⊜ *_cecan_* ━⊜
┃⋄ .animeai
┃⋄ .aiimg
┗━━━━━━━━⬣

┏━━⊜ *_random_* ━⊜
┃⋄ .cina
┗━━━━━━━━⬣

┏━━⊜ *_image_* ━⊜
┃⋄ .hacker
┃⋄ .programing
┃⋄ .wq
┃⋄ .wallpaperquotes
┃⋄ .wpaesthetic
┃⋄ .wpgame
┃⋄ .cristianoronaldo
┃⋄ .cr7
┗━━━━━━━━⬣

┏━━⊜ *_kabul_* ━⊜
┃⋄ .allprofile [@user]
┃⋄ .server <type> <ip> <port>
┃⋄ .waktu <daerah>
┗━━━━━━━━⬣

┏━━⊜ *_quran_* ━⊜
┃⋄ .alquran
┃⋄ .asmaulhusna [1-99]
┃⋄ .ayatkursi
┃⋄ .bacaan_shalat 1-8
┃⋄ .niatsholat
┃⋄ .doatahlil [1-44]
┃⋄ .hadis
┗━━━━━━━━⬣

┏━━⊜ *_limitmenu_* ━⊜
┃⋄ .alquran
┃⋄ .spamwa <number>|<mesage>|<no of messages>
┗━━━━━━━━⬣

┏━━⊜ *_islam_* ━⊜
┃⋄ .doaharian (Ⓛ)
┃⋄ .bacaan_shalat 1-8
┃⋄ .kisahnabi <name>
┃⋄ .murothal
┗━━━━━━━━⬣

┏━━⊜ *_jadian_* ━⊜
┃⋄ .cekpacar
┃⋄ .ikhlasin
┃⋄ .tembak *@tag*
┃⋄ .putus
┃⋄ .tolak *@tag*
┗━━━━━━━━⬣

┏━━⊜ *_database_* ━⊜
┃⋄ .addvn <teks>
┃⋄ .addmsg <teks>
┃⋄ .addvideo <teks>
┃⋄ .addaudio <teks>
┃⋄ .addimg <teks>
┃⋄ .addstiker <teks>
┃⋄ .addgif <teks>
┃⋄ .delmsg <teks>
┃⋄ .unlockmsg <teks>
┃⋄ .lockmsg <teks>
┗━━━━━━━━⬣

┏━━⊜ *_nsfw +18_* ━⊜
┗━━━━━━━━⬣

┏━━⊜ *_nulis_* ━⊜
┃⋄ .tahta <teks>
┃⋄ .nulis <teks>
┃⋄ .nuliskanankiri <teks>
┃⋄ .nuliskiri <teks>
┃⋄ .nuliskanan <teks>
┃⋄ .foliokiri <teks>
┃⋄ .foliokanan <teks>
┗━━━━━━━━⬣

┏━━⊜ *_exp_* ━⊜
┃⋄ .profile <url>
┃⋄ .profile [@user]
┗━━━━━━━━⬣

┏━━⊜ *_sound_* ━⊜
┃⋄ .mangkane1
┃⋄ .mangkane2
┃⋄ .mangkane3
┃⋄ .mangkane4
┃⋄ .mangkane5
┃⋄ .mangkane6
┃⋄ .mangkane7
┃⋄ .mangkane8
┃⋄ .mangkane9
┃⋄ .mangkane10
┃⋄ .mangkane11
┃⋄ .mangkane12
┃⋄ .mangkane13
┃⋄ .mangkane14
┃⋄ .mangkane15
┃⋄ .mangkane16
┃⋄ .mangkane17
┃⋄ .mangkane18
┃⋄ .mangkane19
┃⋄ .mangkane20
┃⋄ .mangkane21
┃⋄ .mangkane22
┃⋄ .mangkane23
┃⋄ .mangkane24
┗━━━━━━━━⬣

┏━━⊜ *_stress_* ━⊜
┃⋄ .genjot
┃⋄ .nenen
┃⋄ .wangy
┃⋄ .curhat
┃⋄ .perkosa
┗━━━━━━━━⬣

┏━━⊜ *_Text→Audio_* ━⊜
┃⋄ .audio <text>
┗━━━━━━━━⬣

┏━━⊜ *_virus_* ━⊜
┃⋄ .bughole
┃⋄ .virusaudiogc <linkgc>
┗━━━━━━━━⬣

┏━━⊜ *_vote_* ━⊜
┃⋄ .cekvote
┃⋄ .hapusvote
┃⋄ .mulaivote [alasan]
┃⋄ .vote
┗━━━━━━━━⬣

┏━━⊜ *_search_* ━⊜
┃⋄ .apa <pencarian>
┃⋄ .yangtzesearch <pencarian>
┗━━━━━━━━⬣

┏━━⊜ *_rpgabsen_* ━⊜
┃⋄ .yearly
┗━━━━━━━━⬣

ꜱɪᴍᴘʟᴇ ʙᴏᴛ ᴡʜᴀᴛꜱᴀᴘᴘ ʙʏ ғᴊ`, m, false)
}
handler.help = ['men']
handler.tags = ['owner']
handler.command = /^(men)$/i
handler.limit = false
handler.premium = false

export default handler