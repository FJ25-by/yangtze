import * as fs from 'fs'

let handler  = async (m, { conn }) => {
  let path = './package.json'
  let data = fs.readFileSync(path, 'utf8')
  let _package = JSON.parse(data)
  let totfit = Object.values(global.plugins).filter(
    (v) => v.help && v.tags
  ).length;

  let versionText = `
┌${htkio} *VERSION* ${htkao}
${pekok} *Nama*: Yangtze
${htto} *By:* FJ
${pekok} *Versi:* 5.7
${htto} *Fitur* : ${totfit}
${pekok} *Team Community*: Phobia Team
└────${htkao}
  `
    conn.sendMessage(m.chat, {
    text: versionText,
    contextInfo: {
      externalAdReply: {
        title: "Yangtze",
        body: "Versi 4.90",
        thumbnailUrl: "https://telegra.ph/file/f2bf046c96fbe315c78e4.jpg",
        sourceUrl: "https://chat.whatsapp.com/HTnGzC3qogRI3Hka64eWYo",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m })
}

handler.help = ['version', 'verbot', 'ver']
handler.tags = ['info']
handler.command = /^(version|verbot|ver)$/i

export default handler