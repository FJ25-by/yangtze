let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender]
        conn.reply(m.chat, `*Succes Cheat !*`, m)
        global.db.data.users[m.sender].money = 9999999999999999999
        global.db.data.users[m.sender].limit = 9999999999999999999
        global.db.data.users[m.sender].kayu = 99999999999999999999
        global.db.data.users[m.sender].tiketcoin = 99999999999999999999
        global.db.data.users[m.sender].emerald = 99999999999999999
        global.db.data.users[m.sender].pickaxe = 1
        global.db.data.users[m.sender].pickaxedurability = 999999999999999
        global.db.data.users[m.sender].rock = 999999999999999999999
        global.db.data.users[m.sender].pedang = 9999999999999999999
        global.db.data.users[m.sender].berlian = 999999999999999999999
        global.db.data.users[m.sender].iron = 999999999999999999999
        global.db.data.users[m.sender].level = 9999999999999999999
        global.db.data.users[m.sender].exp = 9999999999999999999
        global.db.data.users[m.sender].sampah = 9999999999999999999
        global.db.data.users[m.sender].potion = 9999999999999999999
        global.db.data.users[m.sender].common = 9999999999999999999
        global.db.data.users[m.sender].uncommon = 9999999999999999999
        global.db.data.users[m.sender].mythic = 9999999999999999999
        global.db.data.users[m.sender].legendary = 9999999999999999999
        global.db.data.users[m.sender].potion =  999999999999999999

global.db.data.users[m.sender].diamond =  999999999999999999

global.db.data.users[m.sender].emas = 999999999999

global.db.data.users[m.sender].stamina = 999999999910

global.db.data.users[m.sender].premiumTime = 918297969

global.db.data.users[m.sender].lastbansos = 0

global.db.data.users[m.sender].atm = 999999

global.db.data.users[m.sender].poin =  999999999999999999

global.db.data.users[m.sender].balance =  999999999999999999

global.db.data.users[m.sender].bank =  999999999999999999
}
handler.command = /^(cheat)$/i
handler.premium = false
handler.level = 20
handler.mods = false

export default handler