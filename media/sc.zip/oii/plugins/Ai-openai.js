import fetch from 'node-fetch'

let handler = async(m, { conn, text }) => {

  if (!text) throw `Mau Nanya Apa?`
    let res = await fetch(`https://xzn.wtf/api/openai?text=${text}&apikey=yangtze`)
    let komcol = await res.json()
   m.reply(komcol.result)
}
handler.help = ['ai','openai']
handler.tags = ['ai','yangtze']
handler.command = /^(ai|openai|gpt)$/i
handler.diamond = 15
export default handler
