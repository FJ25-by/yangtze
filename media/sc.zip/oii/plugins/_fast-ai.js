import axios from 'axios'
let handler = async(m, { conn, text }) => {
if (!text) throw `Mau Nanya Apa?`
	axios.get(`https://api-fgmods.ddns.net/api/info/openai2?text=${text}&apikey=RF9mFuF7`).then ((res) => {
	 	let hasil = `*${res.data.result}*`

    conn.reply(m.chat, hasil, m)
	})
}
handler.help = ['fast-ai']
handler.tags = ['internet','yangtze']
handler.command = /^(fast-ai)$/i

handler.exp = 0
handler.diamond = 2

export default handler
