
let handler = async (m, { conn }) => {

m.reply(`
≡  *FJᴮᴼᵀ ┃ FJ*

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Nomor *1*
wa.me/6285774510196

▢ Nomor *2*
wa.me/6283852765078

▢ Grupo *NSFW* 🔞
https://chat.whatsapp.com/F0JTTyZ3hsoL7OlU8TEpuH

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Todos los Grupos
 https://instabio.cc/fg98ff

▢ *Telegram*
• https://t.me/Dragon_Ghost25

 ▢ *PayPal*
• https://paypal.me/fg98f

▢ *YouTube*
• https://www.youtube.com/SiMyEx`)

}
handler.help = ['support']
handler.tags = ['main']
handler.command = ['grupos', 'groupdylux', 'dxgp', 'dygp', 'gpdylux', 'support'] 

export default handler
